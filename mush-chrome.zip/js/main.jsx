var React = require("react/addons")

var Root = require("root.jsx")

React.render(<Root />, document.body)


